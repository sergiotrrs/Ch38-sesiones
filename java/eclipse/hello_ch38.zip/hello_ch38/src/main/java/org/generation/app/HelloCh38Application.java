package org.generation.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloCh38Application {

	public static void main(String[] args) {
		SpringApplication.run(HelloCh38Application.class, args);
	}

}
