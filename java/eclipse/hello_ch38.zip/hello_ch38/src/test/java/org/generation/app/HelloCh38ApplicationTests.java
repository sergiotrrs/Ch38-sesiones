package org.generation.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloCh38ApplicationTests {

	@Test
	void contextLoads() {
	}

}
